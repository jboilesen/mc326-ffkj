clear
echo --- Iniciando execucao de testes...
echo
echo --- Teste 1 Iniciado - Arquivo de entrada./files/in/LB02G3_1.txt
./lab02 "./files/in/LB02G3_1.txt" "./files/out/LB02G3_1_SoSep.txt" "./files/out/LB02G3_1_Compacto.txt" 
echo --- Teste 1 Concluido

echo

echo --- Teste 2 Iniciado - Arquivo de entrada./files/in/LB02G3_2.txt
./lab02 "./files/in/LB02G3_2.txt" "./files/out/LB02G3_2_SoSep.txt" "./files/out/LB02G3_2_Compacto.txt" 
echo --- Teste 2 Concluido

echo
echo --- Execucao dos testes concluida.
echo --- Arquivos de saida em './files/out'
echo
