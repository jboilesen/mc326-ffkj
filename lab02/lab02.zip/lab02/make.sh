echo Compilacao Iniciada
gcc -Wall -W -c ./lib/lib.c -o ./lib/lib.o
gcc -Wall -W -c ./lib/configs.c -o ./lib/configs.o
gcc -Wall -W -c ./src/lab02.c -o ./src/lab02.o
gcc -Wall -W ./lib/lib.o ./lib/configs.o ./src/lab02.o -o ./lab02
echo
echo Compilacao Concluida
